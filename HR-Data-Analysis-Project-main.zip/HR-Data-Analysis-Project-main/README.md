# HR-Data-Analysis-
The HR Analytics Dashboard in Power BI offers a clear and interactive view of key workforce metrics.
It helps HR professionals track headcount, attrition, employee demographics, and attendance trends.
The dashboard uses Power BI’s built-in tools for data modeling, transformation, and visualization.
 Users can filter data by department, location, gender, or time period for deeper analysis.
 It supports data-driven HR decisions by presenting real-time insights in an easy-to-understand format.
